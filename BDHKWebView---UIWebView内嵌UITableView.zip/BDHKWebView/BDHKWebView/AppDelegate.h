//
//  AppDelegate.h
//  BDHKWebView
//
//  Created by zhushaobo on 2016/9/29.
//  Copyright © 2016年 Shaobo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

