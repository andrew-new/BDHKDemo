//
//  imageInfo.h
//  webViewDemo
//
//  Created by 徐坤 on 15/6/2.
//  Copyright (c) 2015年 xukun. All rights reserved.
//


/*
 
 {
 alt = "";
 pixel = "431*459";
 ref = "<!--IMG#0-->";
 src = "http://img3.cache.netease.com/m/2015/9/24/2015092417283796819.jpg";
 }

 */


#import <Foundation/Foundation.h>

@interface imageInfo : NSObject

@property(nonatomic,copy)NSString *alt;
@property(nonatomic,copy)NSString *pixel;
@property(nonatomic,copy)NSString *ref;
@property(nonatomic,copy)NSString *src;

- (id)initWithInfo:(NSDictionary *)dic;


@end
